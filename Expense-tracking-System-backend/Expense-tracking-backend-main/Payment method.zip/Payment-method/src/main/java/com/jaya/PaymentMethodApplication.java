package com.jaya;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PaymentMethodApplication {

	public static void main(String[] args) {
		SpringApplication.run(PaymentMethodApplication.class, args);
	}

}
